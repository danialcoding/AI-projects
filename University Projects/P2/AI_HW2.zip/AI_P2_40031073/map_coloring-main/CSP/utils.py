from copy import copy
import random
from typing import List

def is_consistent(graph: dict, variable_value_pairs: dict):
    vv = variable_value_pairs
    for var in graph.keys():
        var_set = graph[var]
        value = vv.get(var, None)
        if value == None:
            continue
        for neighbor in var_set:
            neighbor_value = vv.get(neighbor, None)
            if neighbor_value == None:
                continue
            if value == neighbor_value:
                return False
    return True

def is_solved(graph: dict, variable_value_pairs: dict):
    vv = variable_value_pairs
    for value in vv.values():
        if value is None:
            return False
    for var in graph.keys():
        var_set = graph[var]
        for neighbor in var_set:
            var_value, neighbor_value = vv[var], vv[neighbor]
            if var_value == neighbor_value:
                return False
    return True

def get_next_variable(variable_value_pairs: dict, domains: list[list]):
    vv = variable_value_pairs
    for i in range(len(domains)):
        if vv.get(i, None) == None:
            return i
    return None

def get_chosen_variable(graph, variable_value_pairs, domains):
    vv = variable_value_pairs
    min_domain_size = 100000
    best_vars = []
    for index, value in enumerate(domains):
        if vv[index] != None:
            continue
        if len(value) == min_domain_size:
            best_vars.append(index)
        elif len(value) < min_domain_size:
            min_domain_size = len(value)
            best_vars = [index]
    max_degree = -100000
    chosen_var = best_vars[0]
    for var in best_vars:
        degree = len(graph[var])
        if degree > max_degree:
            max_degree = degree
            chosen_var = var
    return chosen_var

def copy_domain(lst: List[List[int]]):
    return [[int(j) for j in i] for i in lst]

def get_ordered_domain(graph, domains, variable, ordering=False):
    def count_conflicts(domains):
        count = 0
        repeat = True
        while repeat:
            repeat = False
            for var in graph.keys():
                for neighbor in graph[var]:
                    for value_var in domains[var]:
                        found = False
                        for value_neighbor in domains[neighbor]:
                            if (value_neighbor != value_var):
                                found = True
                                break
                        if not found:
                            domains[var].remove(value_var)
                            count += 1
                            repeat = True
        return count

    variable_domain = domains[variable]
    ordered_domain = []
    if ordering:
        for index, value in enumerate(variable_domain):
            temp_domains = copy_domain(domains)
            temp_domains[variable] = [value]
            variable_domain[index] = (count_conflicts(temp_domains), value)
        for item in variable_domain:
            ordered_domain.append(min(ordered_domain, key=lambda tup: tup[0])[1])
        return ordered_domain
    else:
        return variable_domain

def forward_check(graph, variable_value_pairs, domains: List[List], variable, value):

    for neighbor in graph[variable]:
        for domain_value in domains[neighbor]:
            if domain_value == value:
                domains[neighbor].remove(domain_value)
        if len(domains[neighbor]) == 0:
            return True
    return False


def ac3(graph: dict, variable_value_pairs: dict, domains):
    vv = variable_value_pairs
    repeat = True
    while repeat:
        repeat = False
        for var_i in graph.keys():
            for var_j in graph[var_i]:
                for value_k in domains[var_i]:
                    is_found = False
                    for value_l in domains[var_j]:
                        if (value_l != value_k):
                            is_found = True
                            break
                    if not is_found:
                        domains[var_i].remove(value_k)
                        repeat = True
    return not is_consistent(graph, vv)

def random_choose_conflicted_var(graph, variable_value_pairs):
    res = []
    vv = variable_value_pairs
    for var_i in graph.keys():
        for var_j in graph[var_i]:
            if vv[var_i] == vv[var_j]:
                res.append(var_i)
                res.append(var_j)
    return res[random.randint(0, len(res) - 1)]

def get_chosen_value(graph, variable_value_pairs, domains, variable):
    vv = variable_value_pairs
    non_conflicts = []
    for value_var in domains[variable]:
        for neighbor_var in graph[value_var]:
            if value_var != vv[neighbor_var]:
                non_conflicts.append(value_var)
    return non_conflicts[random.randint(0, len(non_conflicts) - 1)]
