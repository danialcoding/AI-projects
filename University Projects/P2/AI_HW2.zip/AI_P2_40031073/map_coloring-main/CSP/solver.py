from ctypes import util
import sys
from typing import List
import cv2
import random
from map import Map
import utils

ESCAPE_KEY_CHARACTER = 27
SLEEP_TIME_IN_MILLISECONDS = 10

GRAPH = {}
COLORED_STATES = {}
N_COLORS = 4
COLORING_COLORS = [(255, 0, 0), (0, 255, 0), (0, 0, 255), (0, 255, 255)]
NONE_COLOR = (0, 0, 0)
BACKTRACK_COUNT = 0
MAP = None
FILTERING_MODE = None
USE_VARIABLE_ORDERING = None
USE_VALUE_ORDERING = None


def colorize_map(manual=False):
    for i in range(len(MAP.nodes)):
        if (COLORED_STATES[i] == None):
            MAP.change_region_color(MAP.nodes[i], NONE_COLOR)
        else:
            MAP.change_region_color(MAP.nodes[i], COLORING_COLORS[COLORED_STATES[i]])
    cv2.imshow('Colorized Map', MAP.image)
    if not manual:
        key = cv2.waitKey(SLEEP_TIME_IN_MILLISECONDS)
    else:
        key = cv2.waitKey()
    if key == ESCAPE_KEY_CHARACTER:
        cv2.destroyAllWindows()
        exit()


'''BACKTRACKING CSP SOLVER'''
def backtrack_solve(domains: List[List]):
    """
        returns True when the CSP is solved, and False when backtracking is neccessary

        you will need to use the global variables GRAPH and COLORED_STATES, refer to preprocess() and try to see what they represent
        use FILTERING_MODE, USE_VARIABLE_ORDERING, and USE_VALUE_ORDERING for branching into each mode
        FILTERING_MODE is either "-n", "-fc", or "ac", and the other two are booleans

        HINT: you may want to import deepcopy to generate the input to the recursive calls
        NOTE: remember to call colorize_map() after each value assingment for the graphical update
              use colorize_map(True) if you want to manually progress by pressing any key
        NOTE: don't forget to update BACKTRACK_COUNT on each backtrack
    """
    global BACKTRACK_COUNT
    if utils.is_solved(GRAPH, COLORED_STATES):
        print("solved")
        print(f"backtrack count: {BACKTRACK_COUNT}")
        colorize_map(True)
        exit(0)

    "*** YOUR CODE HERE ***"
    if not apply_filtering_strategy(domains):
        BACKTRACK_COUNT += 1


def solve_with_no_filtering(domains):
    global BACKTRACK_COUNT
    variable = utils.get_next_variable(COLORED_STATES, domains)
    if USE_VARIABLE_ORDERING:
        variable = utils.get_chosen_variable(GRAPH, COLORED_STATES, domains)
    if variable is None:
        return True  # All variables assigned, should be solved already if here

    for value in utils.get_ordered_domain(GRAPH, domains, variable, USE_VALUE_ORDERING):
        COLORED_STATES[variable] = value
        colorize_map(False)
        if utils.is_consistent(GRAPH, COLORED_STATES):
            if backtrack_solve(domains):
                return True
            BACKTRACK_COUNT += 1
    COLORED_STATES[variable] = None
    return False


def solve_with_forward_checking(domains):
    global BACKTRACK_COUNT
    current_variable = utils.get_next_variable(COLORED_STATES, domains)
    if USE_VALUE_ORDERING:
        current_variable = utils.get_chosen_variable(GRAPH, COLORED_STATES, domains)
    if current_variable is None:
        return True

    for color in utils.get_ordered_domain(GRAPH, domains, current_variable):
        COLORED_STATES[current_variable] = color
        colorize_map(False)
        temp_domains = utils.copy_domain(domains)
        if not utils.forward_check(GRAPH, COLORED_STATES, temp_domains, current_variable, color):
            if backtrack_solve(temp_domains):
                return True
            BACKTRACK_COUNT += 1
    COLORED_STATES[current_variable] = None
    return False


def solve_with_arc_consistency(domains):
    global BACKTRACK_COUNT
    chosen_var = utils.get_next_variable(COLORED_STATES, domains)
    if USE_VALUE_ORDERING:
        chosen_var = utils.get_chosen_variable(GRAPH, COLORED_STATES, domains)
    if chosen_var is None:
        return True

    for possible_value in utils.get_ordered_domain(GRAPH, domains, chosen_var):
        COLORED_STATES[chosen_var] = possible_value
        colorize_map(False)
        modified_domains = utils.copy_domain(domains)
        modified_domains[chosen_var] = [possible_value]
        if not utils.ac3(GRAPH, COLORED_STATES, modified_domains):
            if backtrack_solve(modified_domains):
                return True
            BACKTRACK_COUNT += 1
    COLORED_STATES[chosen_var] = None
    return False


def apply_filtering_strategy(domains):
    if FILTERING_MODE == '-n':
        return solve_with_no_filtering(domains)
    elif FILTERING_MODE == '-fc':
        return solve_with_forward_checking(domains)
    elif FILTERING_MODE == '-ac':
        return solve_with_arc_consistency(domains)
    return False



'''ITERATIVE IMPROVEMENT SOLVER'''


def iterative_improvement_solve(domains):
    """
        you will need to use the global variables GRAPH and COLORED_STATES, refer to preprocess() and try to see what they represent
        don't forget to call colorize_map()
        1. initialize all the variables randomly,
        2. then change the conficting values until solved, use max_steps to avoid infinite loops
    """
    "*** YOUR CODE HERE ***"

    initialize_colors()
    resolve_conflicts()
    colorize_map(True)

    "*** YOUR CODE ENDS HERE ***"
    print("solved")



def initialize_colors():
    for region_id in range(len(COLORED_STATES)):
        COLORED_STATES[region_id] = random.randint(0, N_COLORS - 1)
        colorize_map(False)

def resolve_conflicts():
    while not utils.is_solved(GRAPH, COLORED_STATES):
        conflicted_region = utils.random_choose_conflicted_var(GRAPH, COLORED_STATES)
        if conflicted_region is not None:
            optimal_color = utils.get_chosen_value(GRAPH, COLORED_STATES, domains, conflicted_region)
            COLORED_STATES[conflicted_region] = optimal_color
            colorize_map(False)




def preprocess():
    MAP.initial_preprocessing()
    for vertex in range(len(MAP.nodes)):
        GRAPH[vertex], COLORED_STATES[vertex] = set(), None
    for v in MAP.nodes:
        for adj in v.adj:
            GRAPH[v.id].add(adj)
            GRAPH[adj].add(v.id)


def assign_boolean_value(argument):
    if argument == "-t":
        return True
    elif argument == "-f":
        return False
    else:
        return None


if __name__ == "__main__":
    # sys.argv = dict()
    # sys.argv[1] = '.\\usa.png'
    # sys.argv[2] = '-n'
    # sys.argv[3]  = '-f'
    # sys.argv[4] = '-t'
    try:
        MAP_IMAGE_PATH = sys.argv[1]
        FILTERING_MODE = sys.argv[2]
        is_ii_mode = FILTERING_MODE == "-ii"
        if not is_ii_mode:
            USE_VARIABLE_ORDERING = assign_boolean_value(sys.argv[3])
            USE_VALUE_ORDERING = assign_boolean_value(sys.argv[4])
            if USE_VARIABLE_ORDERING == None or USE_VALUE_ORDERING == None:
                print("invalid ordering flags")
                exit(1)
    except IndexError:
        print("Error: invalid arguments.")
        exit(1)

    try:
        MAP = Map(cv2.imread(MAP_IMAGE_PATH, cv2.IMREAD_COLOR))
    except Exception as e:
        print("Could not read the specified image")
        exit(1)
    preprocess()
    domains = [list(range(N_COLORS)) for _ in range(len(GRAPH.keys()))]
    if not is_ii_mode:
        print(
            f"filtering mode: {FILTERING_MODE}, use variable ordering: {USE_VARIABLE_ORDERING}, use value ordering: {USE_VALUE_ORDERING}")
        backtrack_solve(domains)
    else:
        iterative_improvement_solve(domains)
