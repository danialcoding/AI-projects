import datetime
import random

import chess

import utiles


class Agent:
    """
        Base class for agents.
    """

    def __init__(self, board: chess.Board, next_player) -> None:
        self.board = board
        self.next_player = next_player

    def get_action(self):
        """
            This method receives a GameState object and returns an action based on its strategy.
        """
        pass

    """
            get possible moves : 
                possibleMoves = board.legal_moves

            create a move object from possible move : 
                move = chess.Move.from_uci(str(possible_move))

            push the move : 
                board.push(move)

            pop the last move:
                board.pop(move)
    """


class RandomAgent(Agent):
    def __init__(self, board: chess.Board, next_player):
        super().__init__(board, next_player)

    def get_action(self):
        return self.random()

    def random(self):
        possible_moves_list = list(self.board.legal_moves)

        random_move = random.choice(possible_moves_list)
        return chess.Move.from_uci(str(random_move))


class MinimaxAgent(Agent):
    def __init__(self, board: chess.Board, next_player, depth):
        self.depth = depth
        super().__init__(board, next_player)

    def get_action(self):
        best_move = self.minimax(self.depth, self.next_player, True)
        return best_move[1]

    def minimax(self, depth, turn, is_maximizing):
        if depth == 0 or self.board.is_game_over():
            return evaluate_board_state(self.board, turn), None

        possible_moves = list(self.board.legal_moves)
        if is_maximizing:
            max_eval = float('-inf')
            best_move = None
            for move in possible_moves:
                self.board.push(move)
                eval = self.minimax(depth - 1, self.toggle_player(turn), False)[0]
                self.board.pop()
                if eval > max_eval:
                    max_eval = eval
                    best_move = move
            return max_eval, best_move
        else:
            min_eval = float('inf')
            best_move = None
            for move in possible_moves:
                self.board.push(move)
                eval = self.minimax(depth - 1, self.toggle_player(turn), True)[0]
                self.board.pop()
                if eval < min_eval:
                    min_eval = eval
                    best_move = move
            return min_eval, best_move

    def toggle_player(self, player):
        return 'white' if player == 'black' else 'black'


class AlphaBetaAgent(Agent):
    def __init__(self, board: chess.Board, next_player, depth):
        self.depth = depth
        super().__init__(board, next_player)


    def get_action(self):
        best_move = self.alpha_beta(self.depth, self.next_player, True, float('-inf'), float('inf'))[1]
        return best_move

    def alpha_beta(self, depth, turn, is_maximizing, alpha, beta):
        if depth == 0 or self.board.is_game_over():
            return evaluate_board_state(self.board, self.next_player), None

        possible_moves = list(self.board.legal_moves)

        if is_maximizing:
            max_eval = float('-inf')
            best_move = None
            for move in possible_moves:
                self.board.push(move)
                eval = self.alpha_beta(depth - 1, turn, not is_maximizing, alpha, beta)[0]
                self.board.pop()
                if eval > max_eval:
                    max_eval = eval
                    best_move = move
                alpha = max(alpha, eval)
                if beta <= alpha:
                    break
            return max_eval, best_move
        else:
            min_eval = float('inf')
            best_move = None
            for move in possible_moves:
                self.board.push(move)
                eval = self.alpha_beta(depth - 1, turn, not is_maximizing, alpha, beta)[0]
                self.board.pop()
                if eval < min_eval:
                    min_eval = eval
                    best_move = move
                beta = min(beta, eval)
                if beta <= alpha:
                    break
            return min_eval, best_move

    # def get_action(self):
    #     _, best_move = self.alpha_beta(self.depth, self.next_player, True, float('-inf'), float('inf'))
    #     return best_move
    #
    # def alpha_beta(self, depth, turn, is_maximizing, alpha, beta):
    #     if depth == 0 or self.board.is_game_over():
    #         return evaluate_board_state(self.board, turn), None
    #
    #     best_move = None
    #     if is_maximizing:
    #         max_eval = float('-inf')
    #         for move in list(self.board.legal_moves):
    #             self.board.push(move)
    #             eval, _ = self.alpha_beta(depth - 1, self.toggle_player(turn), False, alpha, beta)
    #             self.board.pop()
    #             if eval > max_eval:
    #                 max_eval = eval
    #                 best_move = move
    #             alpha = max(alpha, eval)
    #             if beta <= alpha:
    #                 break
    #         return max_eval, best_move
    #     else:
    #         min_eval = float('inf')
    #         for move in list(self.board.legal_moves):
    #             self.board.push(move)
    #             eval, _ = self.alpha_beta(depth - 1, self.toggle_player(turn), True, alpha, beta)
    #             self.board.pop()
    #             if eval < min_eval:
    #                 min_eval = eval
    #                 best_move = move
    #             beta = min(beta, eval)
    #             if beta <= alpha:
    #                 break
    #         return min_eval, best_move
    #
    # def toggle_player(self, player):
    #     return 'white' if player == 'black' else 'black'


class ExpectimaxAgent(Agent):
    def __init__(self, board: chess.Board, next_player, depth):
        self.depth = depth
        super().__init__(board, next_player)

    def get_action(self):
        # Start the expectimax search and get the best move
        _, best_move = self.expectimax(self.depth, self.next_player, True)
        return best_move

    def expectimax(self, depth, turn, is_maximizing):
        if depth == 0 or self.board.is_game_over():
            return evaluate_board_state(self.board, turn), None

        best_move = None
        if is_maximizing:
            max_eval = float('-inf')
            for move in list(self.board.legal_moves):
                self.board.push(move)
                eval, _ = self.expectimax(depth - 1, self.toggle_player(turn), False)
                self.board.pop()
                if eval > max_eval:
                    max_eval = eval
                    best_move = move
            return max_eval, best_move
        else:
            # In a real game with opponents, the minimizing player might be simulated differently
            # Here, we assume that the opponent plays optimally for their advantage
            avg_eval = 0
            total_moves = len(list(self.board.legal_moves))
            for move in list(self.board.legal_moves):
                self.board.push(move)
                eval, _ = self.expectimax(depth - 1, self.toggle_player(turn), True)
                self.board.pop()
                avg_eval += eval / total_moves  # Calculate the average evaluation
            return avg_eval, None  # In the chance node, we are not returning any move

    def toggle_player(self, turn):
        return 'white' if turn == 'black' else 'black'





def evaluate_board_state(board, turn):
    node_evaluation = 0
    node_evaluation += utiles.check_status(board, turn)
    node_evaluation += utiles.evaluationBoard(board)
    node_evaluation += utiles.checkmate_status(board, turn)
    node_evaluation += utiles.good_square_moves(board, turn)
    if turn == 'white':
        return node_evaluation
    return -node_evaluation